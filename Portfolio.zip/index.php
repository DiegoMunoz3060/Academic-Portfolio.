<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php echo '<p>Hello World! Here are all of my Links [Diego Munoz & 2 period]</p>'; ?> 
    <ul>
      <li><a href="index.html">index.html</a></li></br>
      <!-- Please make sure to change all the #'s to the proper link names-->
      <li><a href="Munoz_AboutMe.html">AboutMe.html</a></li></br>
      <li><a href="Munoz_Projects.html">Projects.html</a></li></br>
      <li><a href="Munoz_Resume.html">Resume.html</a></li></br>
      <li><a href="Munoz_ContactMe.html">ContactMe.html</a></li></br>
    <ul>
  </body>
</html>